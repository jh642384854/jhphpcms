-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2020-06-09 14:32:09
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `cms_category`
-- -----------------------------
DROP TABLE IF EXISTS `cms_category`;
CREATE TABLE `cms_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `en_name` varchar(200) NOT NULL COMMENT '分类英文名称',
  `modelid` smallint(5) NOT NULL DEFAULT '0' COMMENT '模型ID',
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类父id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:发布,0:不发布',
  `sort` smallint(5) NOT NULL DEFAULT '1' COMMENT '排序',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '分类描述',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '分类层级关系路径',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `haschild` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有子栏目',
  `childids` mediumtext NOT NULL COMMENT '当前栏目下面的所有子栏目ID',
  `is_menu` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否作为菜单显示',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '分类图片',
  `seo_title` varchar(100) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  `category_template` varchar(50) NOT NULL DEFAULT '' COMMENT '栏目页模板页',
  `list_template` varchar(50) NOT NULL DEFAULT '' COMMENT '分类列表模板',
  `show_template` varchar(50) NOT NULL DEFAULT '' COMMENT '分类文章页模板',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='文章分类表';

-- -----------------------------
-- Records of `cms_category`
-- -----------------------------
INSERT INTO `cms_category` VALUES ('1', '新闻中心', 'News', '6', '0', '1', '1', '栏目描述', '0-1', '0', '1', '1,24,25', '1', '', 'SEO标题', 'SEO关键字', 'SEO描述', '', '', '');
INSERT INTO `cms_category` VALUES ('17', '产品中心', 'Products', '7', '0', '1', '5', '', '0-17', '0', '1', '17,26,27', '0', '', '', '', '', 'category.html', 'list.html', 'show.html');
INSERT INTO `cms_category` VALUES ('24', '公司新闻', 'Company News', '6', '1', '1', '1', '', '0-1-24', '0,1', '0', '24', '0', '', '', '', '', 'category.html', 'list.html', 'show.html');
INSERT INTO `cms_category` VALUES ('25', '行业资讯', 'hyzx', '6', '1', '1', '1', '', '0-1-25', '0,1', '0', '25', '0', '', '', '', '', 'category.html', 'list.html', 'show.html');
INSERT INTO `cms_category` VALUES ('26', '产品类别一', '', '7', '17', '1', '1', '', '0-17-26', '0,17', '0', '26', '0', '', '', '', '', 'category.html', 'list.html', 'show.html');
INSERT INTO `cms_category` VALUES ('27', '产品类别2', '', '7', '17', '1', '1', '', '0-17-27', '0,17', '0', '27', '0', '', '', '', '', 'category.html', 'list.html', 'show.html');

-- -----------------------------
-- Table structure for `cms_model_field`
-- -----------------------------
DROP TABLE IF EXISTS `cms_model_field`;
CREATE TABLE `cms_model_field` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `field` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '数据表字段名',
  `title` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '页面展示字段名称',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '字段最大值',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '字段最小值',
  `formtype` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '字段类型',
  `setting` mediumtext COLLATE utf8mb4_bin NOT NULL COMMENT '字段设置信息',
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否是核心字段',
  `isindex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为该字段创建索引',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否作为主表字段',
  `isunique` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '值是否唯一',
  `isbase` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否作为基本信息 该信息将在添加页面左侧显示',
  `issearch` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否作为搜索条件',
  `sort` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否禁用该字段',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `modelid` (`modelid`,`disabled`) USING BTREE,
  KEY `field` (`field`,`modelid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- -----------------------------
-- Records of `cms_model_field`
-- -----------------------------
INSERT INTO `cms_model_field` VALUES ('79', '7', 'catid', '栏目', '1', '6', 'select', '{\"defaultvalue\":\"\"}', '0', '1', '1', '0', '1', '1', '1', '0', '2020-05-26 11:31:18');
INSERT INTO `cms_model_field` VALUES ('80', '7', 'title', '文章标题', '1', '80', 'title', '', '0', '0', '1', '0', '1', '1', '2', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('81', '7', 'keywords', '文章关键字', '0', '150', 'keywords', '{\"size\":\"100\",\"defaultvalue\":\"\"}', '0', '0', '1', '0', '1', '0', '3', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('82', '7', 'tags', '文章标签', '0', '150', 'tags', '{\"size\":\"100\",\"defaultvalue\":\"\"}', '0', '0', '1', '0', '1', '0', '4', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('83', '7', 'description', '文章摘要', '0', '255', 'title', '{\"width\":\"98\",\"height\":\"46\",\"defaultvalue\":\"\",\"enablehtml\":\"0\"}', '0', '0', '1', '0', '1', '0', '5', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('84', '7', 'conent', '内容', '1', '999999', 'editor', '{\"toolbar\":\"full\",\"defaultvalue\":\"\",\"enablekeylink\":\"1\",\"replacenum\":\"2\",\"link_mode\":\"0\",\"enablesaveimage\":\"1\"}', '0', '0', '1', '0', '1', '1', '6', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('85', '7', 'pages', '文章分页方式', '0', '80', 'pages', '', '0', '0', '0', '0', '1', '0', '7', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('86', '7', 'posids', '推荐位', '0', '80', 'posid', '', '0', '0', '0', '0', '1', '0', '8', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('87', '7', 'thumb', '文章缩略图', '1', '100', 'image', '{\"size\":\"50\",\"defaultvalue\":\"\",\"show_type\":\"1\",\"upload_maxsize\":\"1024\",\"upload_allowext\":\"jpg|jpeg|gif|png|bmp\",\"watermark\":\"0\",\"isselectimage\":\"1\",\"images_width\":\"\",\"images_height\":\"\"}', '0', '0', '1', '0', '0', '0', '9', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('88', '7', 'views', '点击量', '0', '10', 'islink', '', '1', '0', '1', '0', '1', '0', '10', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('89', '7', 'copyfrom', '文章来源', '0', '100', 'copyfrom', '{\"defaultvalue\":\"\"}', '0', '0', '0', '0', '1', '0', '11', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('90', '7', 'username', '文章发布者', '0', '20', 'text', '', '0', '0', '1', '0', '1', '0', '12', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('91', '7', 'author', '文章作者', '0', '20', 'text', '', '0', '0', '1', '0', '1', '0', '13', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('92', '7', 'islink', '转向链接', '0', '0', 'islink', '', '1', '0', '1', '0', '1', '0', '14', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('93', '7', 'status', '文章状态', '0', '10', 'box', '', '1', '0', '1', '0', '1', '0', '15', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('94', '7', 'sort', '文章排序', '0', '6', 'number', '', '0', '0', '1', '0', '1', '0', '16', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('95', '7', 'is_deleted', '是否标记为删除', '0', '1', 'radio', '', '0', '0', '1', '0', '1', '0', '17', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('96', '7', 'relation', '相关文章', '0', '0', 'omnipotent', '', '1', '0', '1', '0', '1', '0', '18', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('97', '7', 'create_at', '文章创建时间', '0', '10', 'datetime', '', '0', '0', '1', '0', '1', '0', '19', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('98', '7', 'update_at', '文章更新时间', '0', '10', 'datetime', '', '0', '0', '1', '0', '1', '0', '20', '0', '2020-05-25 17:17:41');
INSERT INTO `cms_model_field` VALUES ('123', '6', 'news_title', '文章标题2', '0', '0', 'text', '{\"width\":\"50\",\"length\":\"255\",\"chartype\":\"varchar\",\"css\":\"layui-input\",\"min\":\"1\",\"tips\":\"\\u8bf7\\u8f93\\u5165\\u6587\\u7ae0\\u6807\\u98982\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-01 17:45:40');
INSERT INTO `cms_model_field` VALUES ('124', '6', 'keywords', '文章关键字', '0', '0', 'text', '{\"tips\":\"\\u8bf7\\u8f93\\u5165\\u6587\\u7ae0\\u5173\\u952e\\u5b57\",\"width\":\"100\",\"length\":\"255\",\"chartype\":\"varchar\",\"css\":\"layui-input\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-02 10:24:31');
INSERT INTO `cms_model_field` VALUES ('125', '6', 'description', '文章摘要', '0', '0', 'textarea', '{\"tips\":\"\\u8bf7\\u8f93\\u5165\\u6587\\u7ae0\\u6458\\u8981\",\"width\":\"100\",\"height\":\"50\",\"chartype\":\"varchar\",\"css\":\"layui-textarea\",\"length\":\"255\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-02 11:49:45');
INSERT INTO `cms_model_field` VALUES ('128', '6', 'select_field', '下拉字段', '0', '0', 'select', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u4e0b\\u62c9\\u5b57\\u6bb5\",\"width\":\"100\",\"options\":\"dock_alliance:1\\r\\ndock_qad:2\\r\\ndock_desktop:3\\r\\ndock_browser:4\\r\\ndock_speed:5\\r\\ndock_speed_desktop:6\\r\\ndock_speed_attach:7\",\"options_from\":\"diyconfig\",\"length\":\"1\",\"chartype\":\"tinyint\",\"pattern\":\"\\/^[0-9-]+$\\/\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-02 15:38:04');
INSERT INTO `cms_model_field` VALUES ('129', '6', 'checkbox_field', '复选框字段', '0', '0', 'checkbox', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u590d\\u9009\\u6846\\u6570\\u636e\",\"options_from\":\"diyconfig\",\"options_module\":\"catgory\",\"options\":\"onebuy_bus:1\\r\\nlol_bus:2\\r\\nsynthesize:3\\r\\nspeed_game:4\\r\\nqad_bus:5\\r\\nlolAD_bus:6\\r\\ndevil_bus:7\",\"chartype\":\"varchar\",\"length\":\"255\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-02 17:52:16');
INSERT INTO `cms_model_field` VALUES ('130', '6', 'radio_field', '单选', '0', '0', 'radio', '{\"tips\":\"12346\",\"options_from\":\"diyconfig\",\"options\":\"onebuy_bus:1\\r\\nlol_bus:2\\r\\nsynthesize:3\\r\\nspeed_game:4\\r\\nqad_bus:5\\r\\nlolAD_bus:6\\r\\ndevil_bus:7\",\"min\":\"1\",\"chartype\":\"tinyint\",\"length\":\"1\",\"pattern\":\"\\/^[0-9-]+$\\/\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 09:23:51');
INSERT INTO `cms_model_field` VALUES ('132', '6', 'date_field', '日期选择器', '0', '0', 'date', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65e5\\u671f\",\"width\":\"100\",\"css\":\"layui-input\",\"min\":\"1\",\"chartype\":\"char\",\"length\":\"10\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 16:29:23');
INSERT INTO `cms_model_field` VALUES ('133', '6', 'time_field', '时间选择器', '0', '0', 'time', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65f6\\u95f4\",\"width\":\"100\",\"css\":\"layui-input\",\"min\":\"1\",\"chartype\":\"char\",\"length\":\"8\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 16:39:48');
INSERT INTO `cms_model_field` VALUES ('134', '6', 'datetime_field', '日期时间字段', '0', '0', 'datetime', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65e5\\u671f\\u65f6\\u95f4\",\"width\":\"100\",\"css\":\"layui-input\",\"min\":\"1\",\"chartype\":\"int\",\"length\":\"10\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 16:43:38');
INSERT INTO `cms_model_field` VALUES ('135', '6', 'daterange_field', '日期范围字段', '0', '0', 'daterange', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65e5\\u671f\\u8303\\u56f4\",\"width\":\"100\",\"css\":\"layui-input\",\"datetime_min_max_isopen\":\"1\",\"datetime_min\":\"2020-06-01\",\"datetime_max\":\"2020-06-30\",\"chartype\":\"varchar\",\"length\":\"50\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 17:08:31');
INSERT INTO `cms_model_field` VALUES ('136', '6', 'timerange_field', '时间范围字段', '0', '0', 'timerange', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65f6\\u95f4\\u8303\\u56f4\",\"width\":\"100\",\"css\":\"layui-input\",\"datetime_min_max_isopen\":\"1\",\"time_min\":\"05:04:05\",\"time_max\":\"22:05:05\",\"chartype\":\"varchar\",\"length\":\"50\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 17:27:01');
INSERT INTO `cms_model_field` VALUES ('137', '6', 'datetime_range_field', '日期时间范围字段', '0', '0', 'datetimerange', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u65e5\\u671f\\u65f6\\u95f4\\u8303\\u56f4\",\"width\":\"100\",\"css\":\"layui-input\",\"datetime_min_max_isopen\":\"1\",\"length\":\"50\",\"chartype\":\"varchar\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-03 17:31:40');
INSERT INTO `cms_model_field` VALUES ('138', '6', 'image_field', '单图字段', '0', '0', 'image', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u56fe\\u7247\",\"width\":\"100\",\"css\":\"layui-input\",\"upload_allowext\":\"jpg,jpeg,png,gif\",\"chartype\":\"varchar\",\"length\":\"100\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 08:57:44');
INSERT INTO `cms_model_field` VALUES ('139', '6', 'images_field', '多图片', '0', '0', 'images', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u56fe\\u7247\",\"width\":\"100\",\"css\":\"layui-input\",\"upload_allowext\":\"jpg,jpeg,png,gif\",\"upload_numbers\":\"10\",\"chartype\":\"varchar\",\"length\":\"200\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 09:24:07');
INSERT INTO `cms_model_field` VALUES ('140', '6', 'file_field', '单文件字段', '0', '0', 'file', '{\"width\":\"100\",\"css\":\"layui-input\",\"upload_allowext\":\"doc,docx,xls,xlsx,ppt,pptx,pdf\",\"chartype\":\"varchar\",\"length\":\"255\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 10:28:57');
INSERT INTO `cms_model_field` VALUES ('141', '6', 'fiels_field', '多文件', '0', '0', 'files', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u591a\\u4e2a\\u6587\\u4ef6\",\"width\":\"100\",\"css\":\"layui-input\",\"upload_allowext\":\"doc,docx,xls,xlsx\",\"upload_numbers\":\"3\",\"length\":\"255\",\"chartype\":\"varchar\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 11:59:56');
INSERT INTO `cms_model_field` VALUES ('142', '6', 'color_field', '颜色字段', '0', '0', 'color_select', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u989c\\u8272\",\"width\":\"100\",\"css\":\"layui-input\",\"color_value_type\":\"hex\",\"chartype\":\"char\",\"length\":\"7\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 15:03:18');
INSERT INTO `cms_model_field` VALUES ('143', '6', 'slider_field', '滑块字段', '0', '0', 'slider', '{\"step\":\"10\",\"minval\":\"1\",\"maxval\":\"100\",\"theme\":\"#ff5722\",\"chartype\":\"char\",\"length\":\"3\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 16:11:02');
INSERT INTO `cms_model_field` VALUES ('144', '6', 'score_field', '评分字段', '0', '0', 'score', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u8bc4\\u5206\",\"theme\":\"#f54f1c\",\"star_length\":\"8\",\"half\":\"0\",\"min\":\"0\",\"length\":\"10\",\"chartype\":\"char\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 16:46:17');
INSERT INTO `cms_model_field` VALUES ('147', '6', 'richtext_field', '富文本字段', '0', '0', 'richtext', '{\"tips\":\"\\u8bf7\\u8f93\\u5165\\u5185\\u5bb9\",\"width\":\"100\",\"height\":\"200\",\"min\":\"1\",\"chartype\":\"text\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-04 17:06:37');
INSERT INTO `cms_model_field` VALUES ('148', '6', 'recommend_field', '推荐位', '0', '0', 'checkbox', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u63a8\\u8350\\u4f4d\",\"options_from\":\"moduledata\",\"options_module\":\"recommend\",\"min\":\"0\",\"chartype\":\"varchar\",\"length\":\"50\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-05 09:55:42');
INSERT INTO `cms_model_field` VALUES ('149', '6', 'radio_recommd_field', '单选推荐位', '0', '0', 'radio', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u5355\\u9009\\u6570\\u636e\",\"options_from\":\"moduledata\",\"options_module\":\"recommend\",\"min\":\"0\",\"chartype\":\"tinyint\",\"length\":\"5\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-05 10:19:48');
INSERT INTO `cms_model_field` VALUES ('150', '6', 'catid', '栏目ID', '0', '0', 'select', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\\u680f\\u76eeID\",\"width\":\"100\",\"min\":\"1\",\"is_multiple\":\"0\",\"options_from\":\"moduledata\",\"options_module\":\"category\",\"length\":\"5\",\"chartype\":\"tinyint\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-05 11:52:50');
INSERT INTO `cms_model_field` VALUES ('151', '6', 'mutil_select_field', '多选字段', '0', '0', 'select', '{\"tips\":\"\\u8bf7\\u9009\\u62e9\",\"width\":\"100\",\"min\":\"1\",\"is_multiple\":\"1\",\"options_from\":\"diyconfig\",\"options\":\"onebuy_bus:1\\r\\nlol_bus:2\\r\\nsynthesize:3\\r\\nspeed_game:4\\r\\nqad_bus:5\\r\\nlolAD_bus:6\\r\\ndevil_bus:7\",\"length\":\"100\",\"chartype\":\"varchar\"}', '1', '0', '1', '0', '1', '0', '0', '0', '2020-06-05 14:12:16');

-- -----------------------------
-- Table structure for `extension_cascader_menu`
-- -----------------------------
DROP TABLE IF EXISTS `extension_cascader_menu`;
CREATE TABLE `extension_cascader_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_bin NOT NULL COMMENT '名称',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `description` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '菜单类别描述',
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- -----------------------------
-- Records of `extension_cascader_menu`
-- -----------------------------
INSERT INTO `extension_cascader_menu` VALUES ('1', '中国地区数据', '1', '中国省市区数据');

-- -----------------------------
-- Table structure for `extension_cascader_menu_data`
-- -----------------------------
DROP TABLE IF EXISTS `extension_cascader_menu_data`;
CREATE TABLE `extension_cascader_menu_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` smallint(5) NOT NULL COMMENT '所属类别',
  `parent_id` int(10) NOT NULL COMMENT '父级ID',
  `name` varchar(100) COLLATE utf8mb4_bin NOT NULL COMMENT '名称',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `sort` smallint(5) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=540 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- -----------------------------
-- Records of `extension_cascader_menu_data`
-- -----------------------------
INSERT INTO `extension_cascader_menu_data` VALUES ('1', '1', '0', '北京', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('2', '1', '0', '广东', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('3', '1', '0', '广西', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('4', '1', '0', '海南', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('5', '1', '0', '重庆', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('6', '1', '0', '四川', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('7', '1', '0', '贵州', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('8', '1', '0', '云南', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('9', '1', '0', '西藏', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('10', '1', '0', '陕西', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('11', '1', '0', '甘肃', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('12', '1', '0', '青海', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('13', '1', '0', '宁夏', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('14', '1', '0', '新疆', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('15', '1', '0', '台湾', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('16', '1', '0', '香港', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('17', '1', '0', '湖南', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('18', '1', '0', '湖北', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('19', '1', '0', '天津', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('20', '1', '0', '河北', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('21', '1', '0', '山西', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('22', '1', '0', '内蒙古', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('23', '1', '0', '辽宁', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('24', '1', '0', '吉林', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('25', '1', '0', '黑龙江', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('26', '1', '0', '上海', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('27', '1', '0', '江苏', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('28', '1', '0', '浙江', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('29', '1', '0', '安徽', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('30', '1', '0', '福建', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('31', '1', '0', '江西', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('32', '1', '0', '山东', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('33', '1', '0', '河南', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('35', '1', '1', '东城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('36', '1', '1', '怀柔区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('37', '1', '1', '大兴区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('38', '1', '1', '昌平区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('39', '1', '1', '顺义区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('40', '1', '1', '通州区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('41', '1', '1', '房山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('42', '1', '1', '门头沟区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('43', '1', '1', '海淀区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('44', '1', '1', '石景山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('45', '1', '1', '丰台区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('46', '1', '1', '朝阳区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('47', '1', '1', '西城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('48', '1', '1', '平谷区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('50', '1', '19', '和平区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('51', '1', '19', '河东区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('52', '1', '19', '河西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('53', '1', '19', '南开区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('54', '1', '19', '河北区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('55', '1', '19', '红桥区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('56', '1', '19', '东丽区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('57', '1', '19', '西青区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('58', '1', '19', '津南区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('59', '1', '19', '北辰区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('60', '1', '19', '武清区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('61', '1', '19', '宝坻区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('62', '1', '19', '滨海新区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('63', '1', '20', '石家庄市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('64', '1', '20', '唐山市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('65', '1', '20', '秦皇岛市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('66', '1', '20', '邯郸市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('67', '1', '20', '邢台市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('68', '1', '20', '保定市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('69', '1', '20', '张家口市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('70', '1', '20', '承德市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('71', '1', '20', '沧州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('72', '1', '20', '廊坊市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('73', '1', '20', '衡水市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('74', '1', '63', '长安区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('75', '1', '63', '桥西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('76', '1', '63', '新华区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('77', '1', '63', '井陉矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('78', '1', '63', '裕华区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('79', '1', '63', '藁城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('80', '1', '63', '鹿泉区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('81', '1', '63', '栾城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('82', '1', '63', '井陉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('83', '1', '63', '正定县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('84', '1', '63', '行唐县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('85', '1', '63', '灵寿县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('86', '1', '63', '高邑县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('87', '1', '63', '深泽县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('88', '1', '63', '赞皇县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('89', '1', '63', '无极县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('90', '1', '63', '平山县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('91', '1', '63', '元氏县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('92', '1', '63', '赵县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('93', '1', '63', '辛集市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('94', '1', '63', '晋州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('95', '1', '63', '新乐市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('96', '1', '64', '路南区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('97', '1', '64', '路北区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('98', '1', '64', '古冶区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('99', '1', '64', '开平区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('100', '1', '64', '丰南区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('101', '1', '64', '丰润区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('102', '1', '64', '曹妃甸区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('103', '1', '64', '滦县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('104', '1', '64', '滦南县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('105', '1', '64', '乐亭县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('106', '1', '64', '迁西县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('107', '1', '64', '玉田县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('108', '1', '64', '遵化市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('109', '1', '64', '迁安市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('110', '1', '65', '海港区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('111', '1', '65', '山海关区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('112', '1', '65', '北戴河区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('113', '1', '65', '青龙满族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('114', '1', '65', '昌黎县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('115', '1', '65', '抚宁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('116', '1', '65', '卢龙县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('117', '1', '66', '邯山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('118', '1', '66', '丛台区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('119', '1', '66', '复兴区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('120', '1', '66', '峰峰矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('121', '1', '66', '邯郸县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('122', '1', '66', '临漳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('123', '1', '66', '成安县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('124', '1', '66', '大名县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('125', '1', '66', '涉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('126', '1', '66', '磁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('127', '1', '66', '肥乡县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('128', '1', '66', '永年县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('129', '1', '66', '邱县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('130', '1', '66', '鸡泽县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('131', '1', '66', '广平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('132', '1', '66', '馆陶县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('133', '1', '66', '魏县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('134', '1', '66', '曲周县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('135', '1', '66', '武安市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('136', '1', '67', '桥东区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('137', '1', '67', '桥西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('138', '1', '67', '邢台县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('139', '1', '67', '临城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('140', '1', '67', '内丘县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('141', '1', '67', '柏乡县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('142', '1', '67', '隆尧县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('143', '1', '67', '任县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('144', '1', '67', '南和县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('145', '1', '67', '宁晋县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('146', '1', '67', '巨鹿县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('147', '1', '67', '新河县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('148', '1', '67', '广宗县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('149', '1', '67', '平乡县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('150', '1', '67', '威县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('151', '1', '67', '清河县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('152', '1', '67', '临西县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('153', '1', '67', '南宫市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('154', '1', '67', '沙河市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('155', '1', '68', '竞秀区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('156', '1', '68', '南市区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('157', '1', '68', '莲池区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('158', '1', '68', '满城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('159', '1', '68', '清苑区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('160', '1', '68', '徐水区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('161', '1', '68', '涞水县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('162', '1', '68', '阜平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('163', '1', '68', '定兴县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('164', '1', '68', '唐县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('165', '1', '68', '高阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('166', '1', '68', '容城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('167', '1', '68', '涞源县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('168', '1', '68', '望都县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('169', '1', '68', '安新县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('170', '1', '68', '易县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('171', '1', '68', '曲阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('172', '1', '68', '蠡县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('173', '1', '68', '顺平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('174', '1', '68', '博野县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('175', '1', '68', '雄县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('176', '1', '68', '涿州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('177', '1', '68', '定州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('178', '1', '68', '安国市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('179', '1', '68', '高碑店市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('180', '1', '69', '桥东区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('181', '1', '69', '桥西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('182', '1', '69', '宣化区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('183', '1', '69', '下花园区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('184', '1', '69', '宣化县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('185', '1', '69', '张北县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('186', '1', '69', '康保县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('187', '1', '69', '沽源县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('188', '1', '69', '尚义县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('189', '1', '69', '蔚县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('190', '1', '69', '阳原县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('191', '1', '69', '怀安县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('192', '1', '69', '万全县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('193', '1', '69', '怀来县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('194', '1', '69', '涿鹿县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('195', '1', '69', '赤城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('196', '1', '69', '崇礼县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('197', '1', '70', '双桥区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('198', '1', '70', '双滦区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('199', '1', '70', '鹰手营子矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('200', '1', '70', '承德县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('201', '1', '70', '兴隆县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('202', '1', '70', '平泉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('203', '1', '70', '滦平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('204', '1', '70', '隆化县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('205', '1', '70', '丰宁满族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('206', '1', '70', '宽城满族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('207', '1', '70', '围场满族蒙古族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('208', '1', '71', '新华区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('209', '1', '71', '运河区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('210', '1', '71', '沧县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('211', '1', '71', '青县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('212', '1', '71', '东光县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('213', '1', '71', '海兴县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('214', '1', '71', '盐山县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('215', '1', '71', '肃宁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('216', '1', '71', '南皮县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('217', '1', '71', '吴桥县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('218', '1', '71', '献县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('219', '1', '71', '孟村回族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('220', '1', '71', '泊头市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('221', '1', '71', '任丘市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('222', '1', '71', '黄骅市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('223', '1', '71', '河间市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('224', '1', '72', '安次区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('225', '1', '72', '广阳区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('226', '1', '72', '固安县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('227', '1', '72', '永清县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('228', '1', '72', '香河县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('229', '1', '72', '大城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('230', '1', '72', '文安县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('231', '1', '72', '大厂回族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('232', '1', '72', '霸州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('233', '1', '72', '三河市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('234', '1', '73', '桃城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('235', '1', '73', '枣强县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('236', '1', '73', '武邑县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('237', '1', '73', '武强县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('238', '1', '73', '饶阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('239', '1', '73', '安平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('240', '1', '73', '故城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('241', '1', '73', '景县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('242', '1', '73', '阜城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('243', '1', '73', '冀州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('244', '1', '73', '深州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('245', '1', '21', '太原市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('246', '1', '21', '大同市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('247', '1', '21', '阳泉市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('248', '1', '21', '长治市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('249', '1', '21', '晋城市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('250', '1', '21', '朔州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('251', '1', '21', '晋中市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('252', '1', '21', '运城市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('253', '1', '21', '忻州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('254', '1', '21', '临汾市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('255', '1', '21', '吕梁市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('256', '1', '245', '小店区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('257', '1', '245', '迎泽区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('258', '1', '245', '杏花岭区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('259', '1', '245', '尖草坪区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('260', '1', '245', '万柏林区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('261', '1', '245', '晋源区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('262', '1', '245', '清徐县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('263', '1', '245', '阳曲县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('264', '1', '245', '娄烦县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('265', '1', '245', '古交市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('266', '1', '246', '城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('267', '1', '246', '矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('268', '1', '246', '南郊区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('269', '1', '246', '新荣区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('270', '1', '246', '阳高县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('271', '1', '246', '天镇县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('272', '1', '246', '广灵县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('273', '1', '246', '灵丘县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('274', '1', '246', '浑源县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('275', '1', '246', '左云县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('276', '1', '246', '大同县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('277', '1', '247', '城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('278', '1', '247', '矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('279', '1', '247', '郊区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('280', '1', '247', '平定县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('281', '1', '247', '盂县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('282', '1', '248', '城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('283', '1', '248', '郊区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('284', '1', '248', '长治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('285', '1', '248', '襄垣县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('286', '1', '248', '屯留县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('287', '1', '248', '平顺县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('288', '1', '248', '黎城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('289', '1', '248', '壶关县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('290', '1', '248', '长子县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('291', '1', '248', '武乡县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('292', '1', '248', '沁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('293', '1', '248', '沁源县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('294', '1', '248', '潞城市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('295', '1', '249', '城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('296', '1', '249', '沁水县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('297', '1', '249', '阳城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('298', '1', '249', '陵川县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('299', '1', '249', '泽州县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('300', '1', '249', '高平市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('301', '1', '250', '朔城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('302', '1', '250', '平鲁区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('303', '1', '250', '山阴县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('304', '1', '250', '应县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('305', '1', '250', '右玉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('306', '1', '250', '怀仁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('307', '1', '251', '榆次区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('308', '1', '251', '榆社县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('309', '1', '251', '左权县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('310', '1', '251', '和顺县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('311', '1', '251', '昔阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('312', '1', '251', '寿阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('313', '1', '251', '太谷县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('314', '1', '251', '祁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('315', '1', '251', '平遥县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('316', '1', '251', '灵石县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('317', '1', '251', '介休市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('318', '1', '252', '盐湖区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('319', '1', '252', '临猗县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('320', '1', '252', '万荣县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('321', '1', '252', '闻喜县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('322', '1', '252', '稷山县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('323', '1', '252', '新绛县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('324', '1', '252', '绛县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('325', '1', '252', '垣曲县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('326', '1', '252', '夏县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('327', '1', '252', '平陆县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('328', '1', '252', '芮城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('329', '1', '252', '永济市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('330', '1', '252', '河津市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('331', '1', '253', '忻府区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('332', '1', '253', '定襄县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('333', '1', '253', '五台县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('334', '1', '253', '代县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('335', '1', '253', '繁峙县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('336', '1', '253', '宁武县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('337', '1', '253', '静乐县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('338', '1', '253', '神池县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('339', '1', '253', '五寨县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('340', '1', '253', '岢岚县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('341', '1', '253', '河曲县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('342', '1', '253', '保德县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('343', '1', '253', '偏关县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('344', '1', '253', '原平市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('345', '1', '254', '尧都区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('346', '1', '254', '曲沃县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('347', '1', '254', '翼城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('348', '1', '254', '襄汾县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('349', '1', '254', '洪洞县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('350', '1', '254', '古县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('351', '1', '254', '安泽县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('352', '1', '254', '浮山县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('353', '1', '254', '吉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('354', '1', '254', '乡宁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('355', '1', '254', '大宁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('356', '1', '254', '隰县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('357', '1', '254', '永和县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('358', '1', '254', '蒲县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('359', '1', '254', '汾西县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('360', '1', '254', '侯马市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('361', '1', '254', '霍州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('362', '1', '255', '离石区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('363', '1', '255', '文水县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('364', '1', '255', '交城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('365', '1', '255', '兴县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('366', '1', '255', '临县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('367', '1', '255', '柳林县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('368', '1', '255', '石楼县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('369', '1', '255', '岚县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('370', '1', '255', '方山县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('371', '1', '255', '中阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('372', '1', '255', '交口县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('373', '1', '255', '孝义市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('374', '1', '255', '汾阳市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('375', '1', '22', '呼和浩特市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('376', '1', '22', '包头市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('377', '1', '22', '乌海市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('378', '1', '22', '赤峰市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('379', '1', '22', '通辽市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('380', '1', '22', '鄂尔多斯市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('381', '1', '22', '呼伦贝尔市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('382', '1', '22', '巴彦淖尔市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('383', '1', '22', '乌兰察布市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('384', '1', '22', '兴安盟', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('385', '1', '22', '锡林郭勒盟', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('386', '1', '22', '阿拉善盟', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('387', '1', '375', '新城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('388', '1', '375', '回民区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('389', '1', '375', '玉泉区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('390', '1', '375', '赛罕区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('391', '1', '375', '土默特左旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('392', '1', '375', '托克托县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('393', '1', '375', '和林格尔县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('394', '1', '375', '清水河县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('395', '1', '375', '武川县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('396', '1', '376', '东河区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('397', '1', '376', '昆都仑区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('398', '1', '376', '青山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('399', '1', '376', '石拐区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('400', '1', '376', '白云鄂博矿区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('401', '1', '376', '九原区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('402', '1', '376', '土默特右旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('403', '1', '376', '固阳县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('404', '1', '376', '达尔罕茂明安联合旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('405', '1', '377', '海勃湾区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('406', '1', '377', '海南区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('407', '1', '377', '乌达区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('408', '1', '378', '红山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('409', '1', '378', '元宝山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('410', '1', '378', '松山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('411', '1', '378', '阿鲁科尔沁旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('412', '1', '378', '巴林左旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('413', '1', '378', '巴林右旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('414', '1', '378', '林西县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('415', '1', '378', '克什克腾旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('416', '1', '378', '翁牛特旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('417', '1', '378', '喀喇沁旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('418', '1', '378', '宁城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('419', '1', '378', '敖汉旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('420', '1', '379', '科尔沁区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('421', '1', '379', '科尔沁左翼中旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('422', '1', '379', '科尔沁左翼后旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('423', '1', '379', '开鲁县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('424', '1', '379', '库伦旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('425', '1', '379', '奈曼旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('426', '1', '379', '扎鲁特旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('427', '1', '379', '霍林郭勒市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('428', '1', '380', '东胜区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('429', '1', '380', '达拉特旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('430', '1', '380', '准格尔旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('431', '1', '380', '鄂托克前旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('432', '1', '380', '鄂托克旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('433', '1', '380', '杭锦旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('434', '1', '380', '乌审旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('435', '1', '380', '伊金霍洛旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('436', '1', '381', '海拉尔区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('437', '1', '381', '扎赉诺尔区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('438', '1', '381', '阿荣旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('439', '1', '381', '莫力达瓦达斡尔族自治旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('440', '1', '381', '鄂伦春自治旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('441', '1', '381', '鄂温克族自治旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('442', '1', '381', '陈巴尔虎旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('443', '1', '381', '新巴尔虎左旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('444', '1', '381', '新巴尔虎右旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('445', '1', '381', '满洲里市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('446', '1', '381', '牙克石市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('447', '1', '381', '扎兰屯市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('448', '1', '381', '额尔古纳市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('449', '1', '381', '根河市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('450', '1', '382', '临河区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('451', '1', '382', '五原县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('452', '1', '382', '磴口县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('453', '1', '382', '乌拉特前旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('454', '1', '382', '乌拉特中旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('455', '1', '382', '乌拉特后旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('456', '1', '382', '杭锦后旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('457', '1', '383', '集宁区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('458', '1', '383', '卓资县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('459', '1', '383', '化德县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('460', '1', '383', '商都县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('461', '1', '383', '兴和县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('462', '1', '383', '凉城县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('463', '1', '383', '察哈尔右翼前旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('464', '1', '383', '察哈尔右翼中旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('465', '1', '383', '察哈尔右翼后旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('466', '1', '383', '四子王旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('467', '1', '383', '丰镇市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('468', '1', '384', '乌兰浩特市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('469', '1', '384', '阿尔山市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('470', '1', '384', '科尔沁右翼前旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('471', '1', '384', '科尔沁右翼中旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('472', '1', '384', '扎赉特旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('473', '1', '384', '突泉县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('474', '1', '385', '二连浩特市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('475', '1', '385', '锡林浩特市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('476', '1', '385', '阿巴嘎旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('477', '1', '385', '苏尼特左旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('478', '1', '385', '苏尼特右旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('479', '1', '385', '东乌珠穆沁旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('480', '1', '385', '西乌珠穆沁旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('481', '1', '385', '太仆寺旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('482', '1', '385', '镶黄旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('483', '1', '385', '正镶白旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('484', '1', '385', '正蓝旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('485', '1', '385', '多伦县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('486', '1', '386', '阿拉善左旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('487', '1', '386', '阿拉善右旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('488', '1', '386', '额济纳旗', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('489', '1', '23', '沈阳市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('490', '1', '23', '大连市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('491', '1', '23', '鞍山市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('492', '1', '23', '抚顺市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('493', '1', '23', '本溪市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('494', '1', '23', '丹东市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('495', '1', '23', '锦州市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('496', '1', '23', '营口市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('497', '1', '23', '阜新市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('498', '1', '23', '辽阳市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('499', '1', '23', '盘锦市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('500', '1', '23', '铁岭市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('501', '1', '23', '朝阳市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('502', '1', '23', '葫芦岛市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('503', '1', '489', '和平区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('504', '1', '489', '沈河区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('505', '1', '489', '大东区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('506', '1', '489', '皇姑区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('507', '1', '489', '铁西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('508', '1', '489', '苏家屯区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('509', '1', '489', '东陵区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('510', '1', '489', '沈北新区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('511', '1', '489', '于洪区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('512', '1', '489', '辽中县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('513', '1', '489', '康平县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('514', '1', '489', '法库县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('515', '1', '489', '新民市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('516', '1', '490', '中山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('517', '1', '490', '西岗区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('518', '1', '490', '沙河口区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('519', '1', '490', '甘井子区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('520', '1', '490', '旅顺口区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('521', '1', '490', '金州区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('522', '1', '490', '长海县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('523', '1', '490', '瓦房店市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('524', '1', '490', '普兰店市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('525', '1', '490', '庄河市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('526', '1', '491', '铁东区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('527', '1', '491', '铁西区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('528', '1', '491', '立山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('529', '1', '491', '千山区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('530', '1', '491', '台安县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('531', '1', '491', '岫岩满族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('532', '1', '491', '海城市', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('533', '1', '492', '新抚区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('534', '1', '492', '东洲区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('535', '1', '492', '望花区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('536', '1', '492', '顺城区', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('537', '1', '492', '抚顺县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('538', '1', '492', '新宾满族自治县', '1', '0');
INSERT INTO `extension_cascader_menu_data` VALUES ('539', '1', '492', '清原满族自治县', '1', '0');
